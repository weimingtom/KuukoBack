﻿/*
 ** $Id: liolib.c,v 2.73.1.3 2008/01/18 17:47:43 roberto Exp $
 ** Standard I/O (and system) library
 ** See Copyright Notice in lua.h
 */
namespace KopiLua
{
	public class FilePtr
	{
        public StreamProxy file;
	}
}
