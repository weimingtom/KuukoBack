package test;

import KopiLua.LuaProgram;

public class Main {
	public static void main(String[] args) {
		LuaProgram.MainLua(args);
	}
}
