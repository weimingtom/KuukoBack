﻿package KopiLua;

public interface luai_jmpbuf {
	//Int32
	//lua_Integer
	void exec(int b);
}