﻿package KopiLua;

public interface Pfunc {
	void exec(lua_State L, Object ud);
}