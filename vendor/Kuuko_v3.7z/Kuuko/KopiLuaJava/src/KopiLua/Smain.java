﻿package KopiLua;

//
//** $Id: lua.c,v 1.160.1.2 2007/12/28 15:32:23 roberto Exp $
//** Lua stand-alone interpreter
//** See Copyright Notice in lua.h
//
public class Smain {
	public int argc;
	public String[] argv;
	public int status;
}