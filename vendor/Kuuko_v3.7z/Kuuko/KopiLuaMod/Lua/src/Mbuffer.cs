﻿/*
 ** $Id: lzio.c,v 1.31.1.1 2007/12/27 13:02:25 roberto Exp $
 ** a generic input stream interface
 ** See Copyright Notice in lua.h
 */
namespace KopiLua
{
	public class Mbuffer
	{
		public CharPtr buffer = new CharPtr();
		public int n; /*uint*/
		public int buffsize; /*uint*/
	}
}

