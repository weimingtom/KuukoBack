﻿namespace KopiLua
{
	public class Program
	{
		static int Main(string[] args)
		{
			if (false)
			{
				LuacProgram.MainLuac(args);
			}
			else
			{
				LuaProgram.MainLua(args);
			}
			return 0;
		}
	}
}
