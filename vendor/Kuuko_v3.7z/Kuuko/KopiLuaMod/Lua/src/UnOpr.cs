﻿/*
 ** $Id: lcode.c,v 2.25.1.3 2007/12/28 15:32:23 roberto Exp $
 ** Code generator for Lua
 ** See Copyright Notice in lua.h
 */
namespace KopiLua
{
	public enum UnOpr 
	{ 
		OPR_MINUS, 
		OPR_NOT, 
		OPR_LEN, 
		OPR_NOUNOPR
	}
}
