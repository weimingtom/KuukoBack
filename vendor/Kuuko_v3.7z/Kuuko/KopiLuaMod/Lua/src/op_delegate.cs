﻿using System;

namespace KopiLua
{
    public interface op_delegate
    {
        /*lua_Number*/
        /*lua_Number*/
        /*lua_Number*/
        Double exec(Double a, Double b);
    }
}
