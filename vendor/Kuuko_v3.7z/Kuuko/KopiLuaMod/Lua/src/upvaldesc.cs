﻿/*
 ** $Id: lparser.c,v 2.42.1.3 2007/12/28 15:32:23 roberto Exp $
 ** Lua Parser
 ** See Copyright Notice in lua.h
 */
namespace KopiLua
{
	public class upvaldesc
	{
		public byte k;  /*Byte*/ /*lu_byte*/
		public byte info;  /*Byte*/ /*lu_byte*/
	}
}
