﻿namespace KopiLua
{
    public interface lua_Alloc
    {
        object exec(ClassType t);
    }
}
